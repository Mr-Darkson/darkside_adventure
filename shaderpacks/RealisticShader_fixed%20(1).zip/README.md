# Realistic Shader (for Minecraft Java Edition)

A GLSL shader pack in the standard OptiFine/Iris format. It adds:

- **Real-time shadow mapping** — a depth-only shadow pass (`shadow.vsh/.fsh`)
  sampled with PCF (percentage-closer filtering) in `gbuffers_terrain.fsh`
  and `gbuffers_water.fsh` for soft-edged, dynamic shadows that move with
  the sun.
- **Screen-space ray traced reflections (SSR)** — `composite.fsh` marches a
  real ray in view space off every pixel proportional to its reflectivity,
  refines the hit point with binary search against the depth buffer, then
  samples the actual color at that hit. Genuine ray-geometry intersection,
  just against on-screen geometry rather than a full voxel scene.
- **Screen-space ray traced global illumination (SSGI)** — same file, nine
  hemisphere-sampled rays per pixel march outward from each surface and
  gather color from whatever they actually hit, giving real bounce
  lighting (a wall next to a red block picks up a red tint) instead of a
  flat ambient term.
- **Temporal accumulation** — `composite.fsh` reprojects each pixel's
  world position into last frame's screen space and blends this frame's
  raw ray-traced result with a history buffer (`colortex2`, using
  OptiFine/Iris's automatic buffer flip for the feedback loop). This is
  the same core technique production real-time ray tracers use to turn a
  handful of noisy samples/pixel into a clean image over a few frames,
  instead of needing brute-force sample counts every single frame.
- **Ray-trace denoising** — `composite1.fsh` runs a normal/depth-aware
  bilateral blur on top of the temporally-accumulated result for the
  remaining spatial noise, without smearing across geometry edges.
- **True volumetric light shafts** — `composite2.fsh` raymarches 32 steps
  through actual 3D space along each camera ray, testing every step
  against the shadow map and accumulating in/out-scattered light with a
  Henyey-Greenstein phase function. This replaces the earlier version's
  2D radial screen blur with a physically-grounded single-scattering
  volumetric model — shafts now correctly thread through gaps in
  geometry instead of just streaking bright pixels.
- **Animated, reflective water** — `gbuffers_water.vsh` displaces the water
  mesh with layered sine waves (a cheap Gerstner-wave approximation) and
  derives a per-pixel normal from it; that normal feeds the SSR pass above.
- **Bloom** — a cheap bright-pass box blur, in `composite1.fsh`.
- **Filmic tonemapping** — an ACES fit + gamma correction + vignette in
  `final.fsh`, so highlights roll off instead of clipping to white.

## Installation

1. Install **OptiFine** or **Iris** (Iris needs Fabric + Sodium).
2. Zip the `shaders` folder (so `shaders/shaders.properties` sits at the
   zip root) and rename it `RealisticShader.zip`, or just drop the
   `shaders` folder itself into `.minecraft/shaderpacks/` as
   `RealisticShader`.
3. In Minecraft: **Options → Video Settings → Shaders...** and select it.
4. In the shader's own options screen, pick a profile:
   - **Performance** — 1K shadow map, no god rays, no bloom.
   - **Balanced** — 2K shadow map, 30 god-ray samples.
   - **Ultra (Heavy Load)** — 4K shadow map, 60 god-ray samples, bloom,
     volumetric flag on. This is the demanding one — the god-ray pass is
     a 60-sample full-screen radial blur run every frame, so expect a
     real GPU hit at high resolutions.

## What kind of "ray tracing" is this, really?

There are two different things people mean by "ray tracing in
Minecraft," and it's worth being precise:

1. **Minecraft RTX / Minecraft with RTX** — Nvidia's DXR path tracer
   built into Bedrock Edition. It builds a full 3D scene and traces
   rays through actual geometry, including stuff off-screen. Requires
   an RTX GPU and isn't something you write as `.vsh/.fsh` files — it's
   a different renderer entirely, exposed through Bedrock resource
   packs (PBR textures), not shader code.

2. **Screen-space ray tracing (SSRT)** — what this pack does, and what
   Java shader packs marketed as "ray traced" (SEUS PTGI, Complementary
   Reimagined's RT mode, Kappa, etc.) actually use under the hood. Real
   rays are marched in 3D and tested against real depth data — this
   isn't a fake — but they can only intersect geometry that's currently
   visible on screen. A reflection of something behind the camera, or
   GI bounced from something off-frame, won't be found because the ray
   marcher has nothing to test against there. It's the same fundamental
   limitation every screen-space technique (SSAO, SSR, SSGI) shares.

For Java Edition, SSRT (now with temporal accumulation) is the realistic
ceiling for a self-authored shader pack without moving to compute shaders
and a voxelized scene (which is what SEUS PTGI itself does — a much larger
project, closer to writing a mini path tracer than a shader pack). This
pack's `composite.fsh` is the actual ray tracing + temporal-accumulation
pass; `composite1.fsh` denoises spatially; `composite2.fsh` adds real
volumetric light shafts.

One honest caveat on the temporal accumulation: it doesn't do full
disocclusion detection (comparing reprojected depth against a stored
previous-frame depth buffer), so it's tuned conservatively. Fast camera
turns or fast-moving entities can show brief ghosting/smearing rather than
the artifact-free result a full disocclusion-aware implementation would
give — that's the corner cut to keep this a readable single-pass addition
rather than a much larger reprojection system.

## Files

```
shaders/
  shaders.properties         — profiles, shadow map resolution, water block ID mapping
  shadow.vsh / .fsh          — depth-only shadow map pass
  gbuffers_terrain.vsh/.fsh  — solid block lighting + shadows; outputs color + normal G-buffer
  gbuffers_water.vsh/.fsh    — wave displacement, fresnel, specular; outputs color + normal G-buffer
  composite.vsh/.fsh         — SSR + SSGI ray marching + temporal accumulation (the ray tracing pass)
  composite1.vsh/.fsh        — bilateral denoise, bloom
  composite2.vsh/.fsh        — true volumetric light shafts (3D shadow-map raymarch)
  final.vsh/.fsh             — tonemapping, gamma, vignette
```

## Tuning

- `MAX_STEPS` (64) / `REFINE_STEPS` (7) in `composite.fsh` — reflection ray
  march length and binary-search precision. Runs on every pixel, not just
  water, since reflectivity is a continuous per-surface value.
- `GI_RAYS` (9) / `GI_STEPS` (16) in `composite.fsh` — bounce-light rays per
  pixel and how far each marches.
- `historyWeight` (0.85) in `composite.fsh` — how much each frame trusts
  temporal history vs. the fresh trace. Higher = smoother/cleaner but more
  prone to ghosting on motion; lower = noisier but more responsive.
- `VOLUMETRIC_STEPS` (32) / `FOG_DENSITY` (0.015) in `composite2.fsh` —
  light shaft quality and thickness.
- `DENOISE_RADIUS` (4) in `composite1.fsh` — wider catches more spatial
  noise but costs more samples and can soften fine detail.
- `shadowMapResolution` in `shaders.properties` — 4096 is heavy, 2048 is
  a good middle ground, 1024 is light.
- The PCF kernel size in `gbuffers_terrain.fsh` (currently 5x5) trades
  shadow softness for sampling cost.
- The `0.06` baseline in `gbuffers_terrain.fsh`'s alpha output controls how
  reflective ordinary terrain is; raise it for a wetter/glossier look,
  lower or zero it to make SSR water-only again.

## Performance note

Every pixel now traces two ray-marched effects (GI + reflection, across the
whole frame) at high sample counts, reprojects and blends against a
temporal history buffer, runs a wide bilateral denoise, a 32-step
volumetric raymarch against the shadow map, and bloom — all in screen
space, every frame. At 4K-shadow / Ultra settings and a high game
resolution this is genuinely demanding — on par with what "RTX" marketing
implies for a rasterizer-based renderer. Drop `GI_RAYS`/`GI_STEPS`,
`MAX_STEPS`, `VOLUMETRIC_STEPS`, and the terrain reflectivity baseline
first if frame rate suffers.
