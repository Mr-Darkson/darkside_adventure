#version 120
/* DRAWBUFFERS:01 */
// colortex0 = lit color, colortex1 = view-space normal (alpha channel doubles
// as a reflectivity flag: 1.0 = water/mirror-like, read back by composite.fsh)

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vNormal;

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex1;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform vec3 sunPosition;

const int   shadowMapResolution = 4096;
const float SHADOW_BIAS         = 0.0012;

// 3x3 PCF — soft shadow edges instead of a hard binary cutoff
float getShadow(vec3 worldPosition) {
    vec4 shadowPos = shadowProjection * shadowModelView * vec4(worldPosition, 1.0);
    shadowPos.xyz = shadowPos.xyz * 0.5 + 0.5;

    float shadow = 0.0;
    float texel = 1.0 / float(shadowMapResolution);
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 offset = vec2(x, y) * texel;
            float depth = texture2D(shadowtex1, shadowPos.xy + offset).r;
            shadow += (shadowPos.z - SHADOW_BIAS > depth) ? 0.0 : 1.0;
        }
    }
    return shadow / 9.0;
}

void main() {
    vec4 lightmapColor = texture2D(lightmap, vLightCoord);

    vec3 n = normalize(vNormal);
    vec3 viewDir = normalize(-vViewPos);

    float fresnel = pow(1.0 - clamp(dot(n, viewDir), 0.0, 1.0), 5.0);
    fresnel = mix(0.02, 1.0, fresnel);

    vec3 deepColor    = vec3(0.02, 0.14, 0.24);
    vec3 shallowColor = vec3(0.10, 0.38, 0.42);
    vec3 waterColor   = mix(deepColor, shallowColor, 0.4);

    vec3 sunDir  = normalize(sunPosition);
    vec3 halfVec = normalize(sunDir + viewDir);
    float spec   = pow(max(dot(n, halfVec), 0.0), 128.0);

    float shadow = getShadow(vWorldPos);

    vec3 skyReflect = vec3(0.65, 0.78, 0.95);
    vec3 finalColor = mix(waterColor, skyReflect, fresnel * 0.65);
    finalColor *= (0.35 + 0.65 * shadow) * lightmapColor.rgb;
    finalColor += spec * shadow * 1.8;

    float alpha = 0.72 + fresnel * 0.25;
    gl_FragData[0] = vec4(finalColor, alpha) * vec4(vColor.rgb, 1.0);
    // alpha here = reflectivity fed to composite.fsh's SSR; water is highly
    // but not perfectly reflective, and fresnel already pushes it higher
    // at grazing angles via the blend below
    gl_FragData[1] = vec4(n * 0.5 + 0.5, clamp(0.6 + fresnel * 0.35, 0.0, 0.95));
}
