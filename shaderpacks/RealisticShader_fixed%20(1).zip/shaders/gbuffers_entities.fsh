#version 120
/* DRAWBUFFERS:01 */
// Lights entities (players/mobs) using the block+sky lightmap the same way
// vanilla does, and writes a normal into colortex1 in the same packed
// format gbuffers_terrain uses, so composite.fsh's SSR/GI pass treats
// entities consistently instead of reading stale/undefined buffer data
// for those pixels.

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vNormal;

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec4 entityColor; // vanilla hurt/flash tint overlay

void main() {
    vec4 albedo = texture2D(texture, vTexCoord) * vColor;
    if (albedo.a < 0.1) discard;

    // Apply vanilla's red hurt-flash / spawn-flash overlay.
    albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);

    vec4 light = texture2D(lightmap, vLightCoord);

    // Entities don't run through the terrain shadow raymarch (they move
    // every frame, so a per-pixel shadow trace here isn't worth the cost).
    // Floor the lightmap contribution instead of multiplying straight
    // through, so an entity standing in a fully-dark lightmap cell never
    // goes to pure black.
    vec3 litColor = albedo.rgb * max(light.rgb, vec3(0.35));

    gl_FragData[0] = vec4(litColor, albedo.a);
    gl_FragData[1] = vec4(normalize(vNormal) * 0.5 + 0.5, 0.06);
}
