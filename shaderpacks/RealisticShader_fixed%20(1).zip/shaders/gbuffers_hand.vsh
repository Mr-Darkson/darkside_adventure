#version 120
// Vertex program for your own first-person hand/held item. This was
// missing entirely -- same root cause as gbuffers_entities.vsh.

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vNormal;

void main() {
    vColor = gl_Color;
    vTexCoord = gl_MultiTexCoord0.xy;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vNormal = normalize(gl_NormalMatrix * gl_Normal);
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}
