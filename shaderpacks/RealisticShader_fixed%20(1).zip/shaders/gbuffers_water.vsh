#version 120

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vNormal;

uniform float frameTimeCounter;

attribute vec4 mc_Entity;

// Layered sine waves approximate a Gerstner wave field cheaply.
// Four waves at different frequencies/directions/speeds give
// a non-repetitive, natural ripple pattern.
float waveHeight(vec2 pos, float t) {
    float h = 0.0;
    h += sin(pos.x * 0.50 + t * 1.20) * 0.050;
    h += sin(pos.y * 0.40 - t * 0.80) * 0.050;
    h += sin((pos.x + pos.y) * 0.25 + t * 1.60) * 0.030;
    h += sin((pos.x - pos.y * 1.3) * 0.15 + t * 0.50) * 0.040;
    return h;
}

void main() {
    vColor = gl_Color;
    vTexCoord = gl_MultiTexCoord0.xy;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;

    vec4 pos = gl_Vertex;
    vWorldPos = (gl_ModelViewMatrixInverse * (gl_ModelViewMatrix * pos)).xyz;

    bool isWater = (mc_Entity.x == 1.0);

    if (isWater) {
        float t = frameTimeCounter * 0.5;
        float h = waveHeight(vWorldPos.xz, t);
        pos.y += h;

        // finite-difference normal from neighbouring wave heights
        float eps = 0.25;
        float hL = waveHeight(vWorldPos.xz - vec2(eps, 0.0), t);
        float hR = waveHeight(vWorldPos.xz + vec2(eps, 0.0), t);
        float hD = waveHeight(vWorldPos.xz - vec2(0.0, eps), t);
        float hU = waveHeight(vWorldPos.xz + vec2(0.0, eps), t);
        vNormal = normalize(vec3(hL - hR, 2.0 * eps, hD - hU));
    } else {
        vNormal = gl_Normal;
    }

    vNormal = normalize(gl_NormalMatrix * vNormal);
    gl_Position = gl_ModelViewProjectionMatrix * pos;
    vViewPos = (gl_ModelViewMatrix * pos).xyz;
}
