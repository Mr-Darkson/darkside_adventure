#version 120

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vNormal;
varying vec3 vWorldPos;

void main() {
    vColor = gl_Color;
    vTexCoord = gl_MultiTexCoord0.xy;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vNormal = normalize(gl_NormalMatrix * gl_Normal);
    vWorldPos = (gl_ModelViewMatrixInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}
