#version 120
/* DRAWBUFFERS:01 */
// Same lighting treatment as gbuffers_entities.fsh, for the held
// item/arm model specifically.

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vNormal;

uniform sampler2D texture;
uniform sampler2D lightmap;

void main() {
    vec4 albedo = texture2D(texture, vTexCoord) * vColor;
    if (albedo.a < 0.1) discard;

    vec4 light = texture2D(lightmap, vLightCoord);
    vec3 litColor = albedo.rgb * max(light.rgb, vec3(0.35));

    gl_FragData[0] = vec4(litColor, albedo.a);
    gl_FragData[1] = vec4(normalize(vNormal) * 0.5 + 0.5, 0.06);
}
