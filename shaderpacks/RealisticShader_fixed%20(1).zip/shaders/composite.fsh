#version 120
/* DRAWBUFFERS:02 */
// This is the ray tracing pass. It doesn't build a voxel scene like SEUS
// PTGI does — instead it ray-marches through the depth+normal G-buffer
// (screen-space ray tracing / SSRT), the same core technique used by most
// modern "ray traced" Java shader packs. Rays are real 3D marches that
// terminate on an actual depth-buffer hit; the limitation is they can only
// hit what's currently on screen.
//
// This version adds temporal accumulation: the GI+reflection result is
// reprojected into last frame's screen position and blended with its
// history (colortex2), the same core idea production ray tracers use to
// turn a few noisy samples/pixel into a clean image over several frames
// instead of needing hundreds of samples in one frame. colortex2 relies on
// OptiFine/Iris's automatic buffer flip: writing to colortex2 here while
// also sampling colortex2 gives you *last* frame's contents, not this
// frame's, which is exactly the feedback loop temporal techniques need.

varying vec2 vTexCoord;

uniform sampler2D colortex0;   // lit color from gbuffers
uniform sampler2D colortex1;   // packed view-space normal (.a = reflectivity 0-1)
uniform sampler2D colortex2;   // previous frame's accumulated RT (GI+reflection) history
uniform sampler2D depthtex0;   // scene depth

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;

vec3 getViewPos(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * clip;
    return view.xyz / view.w;
}

vec2 viewToScreen(vec3 viewPos) {
    vec4 clip = gbufferProjection * vec4(viewPos, 1.0);
    return (clip.xy / clip.w) * 0.5 + 0.5;
}

float rand(vec2 co) {
    return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

// Reprojects a current-frame view-space position into last frame's screen
// UV, accounting for player movement (cameraPosition changes every frame
// in Minecraft's camera-relative coordinate space).
vec2 reprojectToPreviousFrame(vec3 viewPos) {
    vec4 worldPos = gbufferModelViewInverse * vec4(viewPos, 1.0);
    vec3 absoluteWorldPos = worldPos.xyz + cameraPosition;
    vec3 previousRelativePos = absoluteWorldPos - previousCameraPosition;

    vec4 prevView = gbufferPreviousModelView * vec4(previousRelativePos, 1.0);
    vec4 prevClip = gbufferPreviousProjection * prevView;
    return (prevClip.xy / prevClip.w) * 0.5 + 0.5;
}

// Screen-space reflection: marches a real ray, refines the hit with binary
// search, returns .a = 1 on a genuine hit.
vec4 traceReflection(vec3 viewPos, vec3 viewNormal) {
    vec3 dir = reflect(normalize(viewPos), viewNormal);
    vec3 rayPos = viewPos;
    float stepSize = 0.35;
    const int MAX_STEPS = 64;
    const int REFINE_STEPS = 7;

    for (int i = 0; i < MAX_STEPS; i++) {
        vec3 prevPos = rayPos;
        rayPos += dir * stepSize;
        vec2 screenPos = viewToScreen(rayPos);
        if (screenPos.x < 0.0 || screenPos.x > 1.0 || screenPos.y < 0.0 || screenPos.y > 1.0) break;

        float sampledDepth = texture2D(depthtex0, screenPos).r;
        vec3 sampledViewPos = getViewPos(screenPos, sampledDepth);

        if (rayPos.z < sampledViewPos.z) {
            vec3 lo = prevPos;
            vec3 hi = rayPos;
            for (int b = 0; b < REFINE_STEPS; b++) {
                vec3 mid = (lo + hi) * 0.5;
                vec2 midScreen = viewToScreen(mid);
                float midDepth = texture2D(depthtex0, midScreen).r;
                vec3 midView = getViewPos(midScreen, midDepth);
                if (mid.z < midView.z) { hi = mid; } else { lo = mid; }
            }
            vec2 hitScreen = viewToScreen(hi);
            return vec4(texture2D(colortex0, hitScreen).rgb, 1.0);
        }
        stepSize *= 1.06;
    }
    return vec4(0.0);
}

// Screen-space GI: several short hemisphere rays around the surface normal,
// gathering light that's actually bounced off visible geometry.
vec3 traceGI(vec3 viewPos, vec3 viewNormal, float noiseSeed) {
    vec3 gi = vec3(0.0);
    const int GI_RAYS = 9;
    const int GI_STEPS = 16;

    vec3 up = abs(viewNormal.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 tangent = normalize(cross(up, viewNormal));
    vec3 bitangent = cross(viewNormal, tangent);

    for (int i = 0; i < GI_RAYS; i++) {
        float a = (float(i) / float(GI_RAYS)) * 6.2831853 + noiseSeed * 6.2831853;
        float r = 0.4 + 0.5 * rand(vec2(a, noiseSeed));
        vec3 sampleDir = normalize(viewNormal + tangent * cos(a) * r + bitangent * sin(a) * r);

        vec3 rayPos = viewPos + viewNormal * 0.05;
        float stepSize = 0.12;
        for (int s = 0; s < GI_STEPS; s++) {
            rayPos += sampleDir * stepSize;
            vec2 screenPos = viewToScreen(rayPos);
            if (screenPos.x < 0.0 || screenPos.x > 1.0 || screenPos.y < 0.0 || screenPos.y > 1.0) break;

            float sampledDepth = texture2D(depthtex0, screenPos).r;
            vec3 sampledViewPos = getViewPos(screenPos, sampledDepth);

            if (rayPos.z < sampledViewPos.z + 0.05) {
                gi += texture2D(colortex0, screenPos).rgb;
                break;
            }
            stepSize *= 1.2;
        }
    }
    return gi / float(GI_RAYS);
}

void main() {
    vec3 base = texture2D(colortex0, vTexCoord).rgb;
    float depth = texture2D(depthtex0, vTexCoord).r;

    if (depth >= 1.0) {
        gl_FragData[0] = vec4(base, 1.0);
        gl_FragData[1] = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    vec4 packedNormal = texture2D(colortex1, vTexCoord);
    vec3 viewNormal = normalize(packedNormal.rgb * 2.0 - 1.0);
    float reflectivity = packedNormal.a;
    vec3 viewPos = getViewPos(vTexCoord, depth);

    float noiseSeed = rand(vTexCoord + fract(frameTimeCounter));

    // --- raw ray-traced contribution this frame ---
    vec3 rtColor = traceGI(viewPos, viewNormal, noiseSeed) * 0.6;

    if (reflectivity > 0.02) {
        vec4 reflection = traceReflection(viewPos, viewNormal);
        if (reflection.a > 0.5) {
            rtColor = mix(rtColor, rtColor + reflection.rgb * reflectivity, 1.0);
        }
    }

    // --- temporal accumulation: blend against reprojected history ---
    vec2 prevUV = reprojectToPreviousFrame(viewPos);
    float historyWeight = 0.0;
    vec3 history = vec3(0.0);

    bool inBounds = prevUV.x > 0.0 && prevUV.x < 1.0 && prevUV.y > 0.0 && prevUV.y < 1.0;
    if (inBounds) {
        history = texture2D(colortex2, prevUV).rgb;
        // Heavier trust in history when the camera isn't moving fast;
        // no depth-based disocclusion test here, so keep this conservative
        // rather than fully committing to a long history (avoids ghosting
        // on fast camera turns / moving geometry).
        historyWeight = 0.75;
    }

    vec3 accumulated = mix(rtColor, history, historyWeight);

    // Keep colortex0 as the SHARP, un-blurred base color. The noisy RT
    // layer goes out only through colortex2, where composite1 denoises
    // it in isolation and adds it back on top of this sharp base. Adding
    // it here (base + accumulated) is what previously forced composite1
    // to blur the entire finished frame instead of just the noise.
    gl_FragData[0] = vec4(base, 1.0);
    gl_FragData[1] = vec4(accumulated, 1.0);
}
