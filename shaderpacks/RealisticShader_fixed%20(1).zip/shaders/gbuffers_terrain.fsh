#version 120
/* DRAWBUFFERS:01 */
// Writes lit color to colortex0 and view-space normal to colortex1.
// colortex1 is consumed later by composite.fsh to ray-march reflections/GI.

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vNormal;
varying vec3 vWorldPos;

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex1;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform vec3 sunPosition;

const int   shadowMapResolution = 4096;
const float SHADOW_BIAS         = 0.0015;

// 5x5 PCF for softer, more natural terrain shadows than water's 3x3
float getShadow(vec3 worldPosition) {
    vec4 shadowPos = shadowProjection * shadowModelView * vec4(worldPosition, 1.0);
    shadowPos.xyz = shadowPos.xyz * 0.5 + 0.5;

    float shadow = 0.0;
    float texel = 1.0 / float(shadowMapResolution);
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            vec2 offset = vec2(x, y) * texel;
            float depth = texture2D(shadowtex1, shadowPos.xy + offset).r;
            shadow += (shadowPos.z - SHADOW_BIAS > depth) ? 0.0 : 1.0;
        }
    }
    return shadow / 25.0;
}

void main() {
    vec4 albedo = texture2D(texture, vTexCoord) * vColor;
    if (albedo.a < 0.1) discard;

    vec4 light = texture2D(lightmap, vLightCoord);

    vec3 sunDir = normalize(sunPosition);
    float NdotL = max(dot(normalize(vNormal), sunDir), 0.0);

    float shadow = getShadow(vWorldPos);
    float diffuse = NdotL * shadow;

    vec3 ambient = albedo.rgb * light.rgb * 0.45;
    vec3 direct  = albedo.rgb * diffuse * 1.25 * vec3(1.0, 0.97, 0.9);

    // buffer 0: lit color, consumed as the "direct lighting" base by composite's SSGI
    gl_FragData[0] = vec4(ambient + direct, albedo.a);
    // buffer 1: view-space normal packed to [0,1]; alpha = reflectivity (0-1),
    // read by composite.fsh's SSR as a continuous value, not a binary flag.
    // A small non-zero base gives every surface subtle real reflections
    // (the "everything has some specular response" PBR behaviour) instead
    // of only water being reflective.
    gl_FragData[1] = vec4(normalize(vNormal) * 0.5 + 0.5, 0.06);
}
