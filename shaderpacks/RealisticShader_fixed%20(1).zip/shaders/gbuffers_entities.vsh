#version 120
// Vertex program for other players, mobs, and dropped items. Without this
// file the pack had no entity stage at all, so entities fell back to a
// mismatched default program that never wrote proper lighting/normal data
// into this pack's buffers -- that's what rendered them solid black.

varying vec4 vColor;
varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec3 vNormal;

void main() {
    vColor = gl_Color;
    vTexCoord = gl_MultiTexCoord0.xy;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vNormal = normalize(gl_NormalMatrix * gl_Normal);
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}
