#version 120

void main() {
    // Depth-only pass — colour is unused, only the depth buffer matters
    gl_FragColor = vec4(1.0);
}
