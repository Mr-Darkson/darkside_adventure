#version 120
/* DRAWBUFFERS:0 */
// The SSGI/SSR pass is noisy by nature even with temporal accumulation
// smoothing it across frames. This pass runs a bilateral blur guided by
// colortex1's normal buffer so it smooths remaining spatial noise along
// flat surfaces but stops at geometry edges, then applies bloom. Real
// volumetric light shafts (a proper 3D raymarch through the shadow map,
// not a 2D screen blur) now happen afterward in composite2.fsh.
//
// IMPORTANT: colortex0 here is the SHARP base scene color (composite.fsh
// no longer merges the noisy RT layer into it). Only colortex2 (the raw
// GI/reflection contribution) gets blurred. That's what keeps terrain,
// water, and distant geometry crisp instead of the whole frame going soft.

varying vec2 vTexCoord;

uniform sampler2D colortex0;   // sharp base color
uniform sampler2D colortex1;   // packed view-space normal (.a = reflectivity)
uniform sampler2D colortex2;   // this frame's raw accumulated RT contribution (noisy)
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform float viewWidth;
uniform float viewHeight;

const int BLOOM_RADIUS    = 3;
const int DENOISE_RADIUS  = 3;

vec3 getViewPos(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * clip;
    return view.xyz / view.w;
}

vec3 denoiseRT(vec2 uv) {
    vec3 centerNormal = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
    float centerDepth = texture2D(depthtex0, uv).r;
    // Compare actual view-space distance rather than raw depth-buffer
    // values. Raw depth is nonlinear and compresses hard at range, so two
    // points meters apart in the world can look almost identical in depth
    // and used to slip past the edge check -- that's what caused blur to
    // get worse the farther out you looked. Linear distance fixes that.
    float centerDist = length(getViewPos(uv, centerDepth));

    vec3 sum = vec3(0.0);
    float totalWeight = 0.0;
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);

    for (int x = -DENOISE_RADIUS; x <= DENOISE_RADIUS; x++) {
        for (int y = -DENOISE_RADIUS; y <= DENOISE_RADIUS; y++) {
            vec2 offset = vec2(x, y) * texel * 1.5;
            vec2 sampleUV = uv + offset;

            vec3 sampleNormal = normalize(texture2D(colortex1, sampleUV).rgb * 2.0 - 1.0);
            float sampleDepth = texture2D(depthtex0, sampleUV).r;
            float sampleDist = length(getViewPos(sampleUV, sampleDepth));

            float normalWeight = pow(max(dot(centerNormal, sampleNormal), 0.0), 16.0);
            // Distance-relative threshold: a fixed-world-unit gap should
            // matter less when everything is already far away, so scale
            // by how far the center point itself is.
            float relGap = abs(centerDist - sampleDist) / max(centerDist, 1.0);
            float depthWeight = 1.0 / (1.0 + relGap * 40.0);
            float weight = normalWeight * depthWeight;

            sum += texture2D(colortex2, sampleUV).rgb * weight;
            totalWeight += weight;
        }
    }

    return totalWeight > 0.0 ? sum / totalWeight : texture2D(colortex2, uv).rgb;
}

void main() {
    vec3 base = texture2D(colortex0, vTexCoord).rgb;
    vec3 rt = denoiseRT(vTexCoord);
    vec3 color = base + rt;

    vec3 bloom = vec3(0.0);
    float count = 0.0;
    for (int x = -BLOOM_RADIUS; x <= BLOOM_RADIUS; x++) {
        for (int y = -BLOOM_RADIUS; y <= BLOOM_RADIUS; y++) {
            vec2 offset = vec2(x, y) / vec2(viewWidth, viewHeight) * 2.0;
            vec3 s = texture2D(colortex0, vTexCoord + offset).rgb;
            float brightness = dot(s, vec3(0.2126, 0.7152, 0.0722));
            if (brightness > 0.9) {
                bloom += s;
                count += 1.0;
            }
        }
    }
    if (count > 0.0) {
        color += (bloom / count) * 0.15;
    }

    gl_FragColor = vec4(color, 1.0);
}
