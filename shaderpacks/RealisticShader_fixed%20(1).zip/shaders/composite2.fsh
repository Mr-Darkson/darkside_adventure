#version 120
/* DRAWBUFFERS:0 */
// True volumetric light shafts. Previous versions of this pack faked god
// rays with a 2D radial blur toward the sun's screen position — cheap, but
// not physically grounded and it streaks whatever's already bright rather
// than modeling light actually scattering through air.
//
// This instead marches a real ray through 3D space from the camera to each
// pixel's surface, and at every step tests that point against the shadow
// map: if the sun can "see" that point in space, it contributes in-
// scattered light; if it's shadowed, it doesn't. Accumulating that along
// the ray is a standard raymarched single-scattering volumetric model —
// the same core idea behind proper volumetric fog/god rays in shaders like
// Continuum or BSL, just without shadow-map cascades or noise-based fog
// density.

varying vec2 vTexCoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex1;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform vec3 sunPosition;
uniform float frameTimeCounter;

const int   VOLUMETRIC_STEPS = 32;
const float FOG_DENSITY      = 0.008;
const float MAX_RAY_DISTANCE = 120.0;
const float SCATTER_STRENGTH = 0.9;   // was 2.2 - blowing highlights to white
const float NEAR_FADE        = 8.0;   // blocks of no-fog near the camera
const int   shadowMapResolution = 4096;

vec3 getViewPos(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * clip;
    return view.xyz / view.w;
}

float rand(vec2 co) {
    return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

// Simple Henyey-Greenstein phase function — real air/fog scatters light
// preferentially forward, this is the standard model for that.
float phaseHG(float cosTheta, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * 3.14159265 * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));
}

float sampleShadow(vec3 worldPos) {
    vec4 shadowPos = shadowProjection * shadowModelView * vec4(worldPos, 1.0);
    shadowPos.xyz = shadowPos.xyz * 0.5 + 0.5;
    if (shadowPos.x < 0.0 || shadowPos.x > 1.0 || shadowPos.y < 0.0 || shadowPos.y > 1.0) return 1.0;
    float depth = texture2D(shadowtex1, shadowPos.xy).r;
    return (shadowPos.z - 0.0015 > depth) ? 0.0 : 1.0;
}

void main() {
    vec3 base = texture2D(colortex0, vTexCoord).rgb;
    float depth = texture2D(depthtex0, vTexCoord).r;

    vec3 viewPos = getViewPos(vTexCoord, depth);
    float surfaceDistance = depth >= 1.0 ? MAX_RAY_DISTANCE : length(viewPos);
    float rayDistance = min(surfaceDistance, MAX_RAY_DISTANCE);

    vec3 viewDir = normalize(viewPos);
    float stepLength = rayDistance / float(VOLUMETRIC_STEPS);

    // Dither the ray start along its own direction to trade banding for
    // noise — standard raymarch trick, cheap and looks far less artificial.
    float jitter = rand(vTexCoord + fract(frameTimeCounter)) * stepLength;

    vec3 sunDir = normalize(sunPosition);
    float cosTheta = dot(-viewDir, sunDir);
    float phase = phaseHG(cosTheta, 0.6);

    vec3 scattered = vec3(0.0);
    float transmittance = 1.0;

    for (int i = 0; i < VOLUMETRIC_STEPS; i++) {
        float t = jitter + stepLength * float(i);
        vec3 samplePos = viewDir * t;
        vec3 worldPos = (gbufferModelViewInverse * vec4(samplePos, 1.0)).xyz;

        // Fade fog in over the first few blocks instead of applying full
        // density starting at the camera -- that's what was hazing over
        // even close-up terrain.
        float nearFade = clamp(t / NEAR_FADE, 0.0, 1.0);

        float lit = sampleShadow(worldPos);
        float density = FOG_DENSITY * stepLength * nearFade;

        scattered += lit * phase * density * transmittance * vec3(1.0, 0.95, 0.85);
        transmittance *= exp(-density);
    }

    // Clamp so in-scattering can't blow past white before tonemapping
    // even gets a chance to roll it off.
    scattered = min(scattered * SCATTER_STRENGTH, vec3(0.8));

    vec3 color = base * transmittance + scattered;
    gl_FragData[0] = vec4(color, 1.0);
}
