#version 120

void main() {
    gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;
    // Small depth bias to reduce shadow acne / peter-panning
    gl_Position.z -= 0.0005;
}
