#version 120

varying vec2 vTexCoord;
uniform sampler2D colortex0;

// ACES filmic tonemap approximation (Narkowicz fit) — keeps highlights
// from clipping harshly and gives a more "cinematic" realistic look
// than clamped Reinhard.
vec3 ACESFilm(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

void main() {
    vec3 color = texture2D(colortex0, vTexCoord).rgb;

    color = ACESFilm(color * 1.2);
    color = pow(color, vec3(1.0 / 2.2));

    float dist = distance(vTexCoord, vec2(0.5));
    float vignette = smoothstep(0.8, 0.35, dist);
    color *= mix(0.7, 1.0, vignette);

    gl_FragColor = vec4(color, 1.0);
}
