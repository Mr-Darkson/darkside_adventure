float GetBirdHash(float seed) {
    return fract(sin(seed * 78.233) * 12543.123);
}

float DistToSegment(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a, ba = b - a;
    float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    return length(pa - ba * h);
}

// Small flapping-wing silhouettes that drift across the daytime sky.
// Birds are randomly black or white, matching the flock style requested.
// Rendered directly as procedural shapes (shaderpacks can't spawn real
// game entities), reusing the same 2D sky projection as the stars.
vec3 ApplyFlyingBirds(vec3 color, vec2 starCoord, float VdotU, float dayFactor) {
    if (dayFactor < 0.05 || VdotU < 0.15) return color;

    for (int i = 0; i < FLYING_BIRDS_AMOUNT; i++) {
        float seed = float(i) * 17.0 + 3.0;

        float speed = 0.015 + GetBirdHash(seed + 1.0) * 0.02;
        float phase = GetBirdHash(seed + 2.0);
        float laneY = (GetBirdHash(seed + 3.0) - 0.5) * 1.4; // within the sky's real visible coordinate range
        float dir   = GetBirdHash(seed + 4.0) > 0.5 ? 1.0 : -1.0;

        float travel = fract(syncedTime * speed + phase) * 3.2 - 1.6; // spans -1.6..1.6, loops
        vec2 birdPos = vec2(travel * dir, laneY);
        float wingSpan = 0.05;

        // Cheap early-out: skip the expensive segment math entirely for pixels
        // nowhere near this bird's rough position (most pixels, most of the time)
        if (length(starCoord - birdPos) > wingSpan * 4.0) continue;

        // Wing flap animation
        float flap = sin(syncedTime * (3.0 + GetBirdHash(seed + 5.0) * 2.0) + phase * 6.28318) * 0.35 + 0.45;

        vec2 leftWingTip  = birdPos + vec2(-wingSpan, flap * wingSpan);
        vec2 rightWingTip = birdPos + vec2( wingSpan, flap * wingSpan);

        float d = min(DistToSegment(starCoord, leftWingTip, birdPos), DistToSegment(starCoord, birdPos, rightWingTip));
        float birdShape = max0(1.0 - d * 700.0);
        birdShape *= birdShape;

        // Fade in/out near the edges of each bird's travel range so they don't pop
        float edgeFade = 1.0 - smoothstep(1.4, 1.6, abs(travel));
        float mask = birdShape * edgeFade * dayFactor;

        bool isWhite = GetBirdHash(seed + 6.0) > 0.5;
        if (isWhite) {
            color += mask * vec3(1.4, 1.4, 1.45);
        } else {
            // Darken toward black for the silhouette - safe multiply, never negative
            color *= (1.0 - mask * 0.92);
        }
    }

    return color;
}
