#include "/lib/colors/skyColors.glsl"

float GetStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

vec2 GetStarCoord(vec3 viewPos, float sphereness) {
    vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos * 1000.0, 1.0)).xyz);
    vec3 starCoord = wpos / (wpos.y + length(wpos.xz) * sphereness);
    starCoord.x += 0.006 * syncedTime;
    return starCoord.xz;
}

vec3 GetStars(vec2 starCoord, float VdotU, float VdotS) {
    #if NIGHT_STAR_AMOUNT == 0
        return vec3(0.0, 0.0, 0.0);
    #endif
    if (VdotU < 0.0) return vec3(0.0);

    starCoord *= 0.2;
    float starFactor = 1024.0;
    starCoord = floor(starCoord * starFactor) / starFactor;

    float star = 1.0;
    star *= GetStarNoise(starCoord.xy);
    star *= GetStarNoise(starCoord.xy+0.1);
    star *= GetStarNoise(starCoord.xy+0.23);

    #if NIGHT_STAR_AMOUNT == 1
        star -= 0.82;
        star *= 2.0;
    #elif NIGHT_STAR_AMOUNT == 2
        star -= 0.7;
    #elif NIGHT_STAR_AMOUNT == 3
        star -= 0.62;
        star *= 0.75;
    #elif NIGHT_STAR_AMOUNT == 4
        star -= 0.52;
        star *= 0.55;
    #endif
    star = max0(star);
    star *= star;

    star *= min1(VdotU * 3.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));
    star *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.5 * sunVisibility);

    return 40.0 * star * vec3(0.38, 0.4, 0.5);
}

#if METEOR_SHOWERS == 1
float GetMeteorHash(float seed) {
    return fract(sin(seed * 12.9898) * 43758.5453);
}

vec3 GetMeteors(vec2 starCoord, float VdotU, float VdotS) {
    if (VdotU < 0.05) return vec3(0.0);

    // One "slot" every few seconds; each slot may or may not spawn a meteor
    float cycleDuration = 16.0 - METEOR_FREQUENCY * 2.5; // higher METEOR_FREQUENCY = shorter wait between chances
    float cycleIndex = floor(syncedTime / cycleDuration);
    float cycleT = fract(syncedTime / cycleDuration);

    float spawnRoll = GetMeteorHash(cycleIndex * 3.17 + 11.0);
    if (spawnRoll > 0.55) return vec3(0.0); // ~55% of slots get a meteor

    // Randomize this meteor's start point, direction and length using the slot index as seed
    float rx = GetMeteorHash(cycleIndex * 7.31 + 1.0);
    float ry = GetMeteorHash(cycleIndex * 5.53 + 2.0);
    float rAngle = GetMeteorHash(cycleIndex * 9.17 + 3.0) * 6.28318 + 3.9; // biased to mostly angle downward/sideways
    float rLenMult = 0.6 + GetMeteorHash(cycleIndex * 4.11 + 4.0) * 0.8;

    vec2 startPos = (vec2(rx, ry) - 0.5) * 3.0; // fits within the sky's real visible coordinate range
    vec2 dir = vec2(cos(rAngle), sin(rAngle));
    float travelDist = 1.4 * rLenMult;

    float activeWindow = 0.3; // meteor is only actually streaking during the first 30% of its slot
    if (cycleT > activeWindow) return vec3(0.0);
    float travelT = cycleT / activeWindow;

    vec2 headPos = startPos + dir * travelDist * travelT;
    float trailLen = 0.15 * rLenMult;

    // Cheap early-out before the more precise (and pricier) trail-distance math
    if (length(starCoord - headPos) > (trailLen + 0.01) * 3.0) return vec3(0.0);

    vec2 toPoint = starCoord - headPos;
    float alongTrail = clamp(dot(toPoint, -dir), 0.0, trailLen);
    vec2 closestPoint = headPos - dir * alongTrail;
    float distToTrail = length(starCoord - closestPoint);

    float trailFade = 1.0 - (alongTrail / trailLen);
    float widthFalloff = max0(1.0 - distToTrail * 550.0);
    widthFalloff *= widthFalloff;

    float fadeInOut = min1(travelT * 6.0) * min1((1.0 - travelT) * 3.0);

    float brightness = widthFalloff * trailFade * fadeInOut;
    brightness *= min1(VdotU * 4.0);
    brightness *= max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));
    brightness *= invRainFactor * pow2(invNoonFactor2) * (1.0 - 0.5 * sunVisibility);

    return 85.0 * brightness * vec3(0.85, 0.92, 1.0);
}
#endif

#if MILKY_WAY == 1
float GetMilkyWayNoise(vec2 pos) {
    float n = 0.0;
    float amp = 0.6;
    float scale = 1.0;
    for (int i = 0; i < 4; i++) {
        vec2 cell = floor(pos * scale) / scale;
        n += GetStarNoise(cell) * amp;
        scale *= 2.17;
        amp *= 0.55;
    }
    return n;
}

vec3 GetMilkyWay(vec2 starCoord, float VdotU, float VdotS) {
    if (VdotU < 0.0) return vec3(0.0);

    // Only visible with little to no nearby block light (torches, lava, glowstone, etc.)
    float localLight = float(eyeBrightness.x) / 240.0;
    float localLightSuppression = 1.0 - min1(localLight * 2.2);
    if (localLightSuppression <= 0.001) return vec3(0.0);

    // Fixed diagonal band across the sky dome
    float bandAngle = 0.65;
    vec2 bandAxis = vec2(cos(bandAngle), sin(bandAngle));
    float distFromBand = dot(starCoord, vec2(-bandAxis.y, bandAxis.x));

    float bandWidth = 0.9;
    float bandShape = exp(-pow(distFromBand / bandWidth, 2.0));

    // Cheap early-out: skip both expensive 4-octave noise calls entirely
    // for pixels clearly outside the band (most of the sky, most of the time)
    if (bandShape < 0.01) return vec3(0.0);

    float texture1 = GetMilkyWayNoise(starCoord * 0.35);
    float texture2 = GetMilkyWayNoise(starCoord * 0.9 + 4.0);
    float cloudTexture = clamp(texture1 * 0.7 + texture2 * 0.5, 0.0, 1.0);

    float milkyWay = bandShape * (0.5 + 0.5 * cloudTexture);

    milkyWay *= min1(VdotU * 2.5) * max0(1.0 - pow(abs(VdotS) * 1.002, 60.0));
    milkyWay *= invRainFactor * pow2(invNoonFactor2) * (1.0 - 0.5 * sunVisibility);
    milkyWay *= localLightSuppression;

    return 7.0 * milkyWay * vec3(0.75, 0.8, 0.95);
}
#endif

#if VIVID_EASTER_EGG == 1
// A hidden, rare surprise - a single shimmering rainbow star at a fixed
// point in the night sky, only visible on rare, semi-random nights.
// Uses the same fixed-3D-direction technique as the End dimension's
// black holes/planets (proven reliable) rather than the 2D sky
// projection (which caused real bugs earlier in this pack's history
// when miscalibrated) - this is a single fixed point, not a moving
// object, so the simpler/safer technique fits perfectly here too.
vec3 ApplyVividEasterEgg(vec3 color, vec3 wpos, float VdotU) {
    if (sunVisibility > 0.05 || VdotU < 0.3) return color;

    // Only appears on roughly 1 in 40 "nights" (coarse time bucket)
    float nightSeed = floor(syncedTime / 1200.0);
    float rareRoll = fract(sin(nightSeed * 91.345) * 47453.234);
    if (rareRoll > 0.025) return color;

    vec3 starDir = normalize(vec3(-0.25, 0.65, 0.55));
    float angDot = dot(wpos, starDir);
    if (angDot < 0.9978) return color;

    float dist = 1.0 - angDot;
    float glow = pow(max0(1.0 - dist / 0.0006), 1.5);

    vec3 rainbow = vec3(
        0.5 + 0.5 * sin(syncedTime * 2.0),
        0.5 + 0.5 * sin(syncedTime * 2.0 + 2.094),
        0.5 + 0.5 * sin(syncedTime * 2.0 + 4.188)
    );

    color += glow * rainbow * 60.0 * invRainFactor;
    return color;
}
#endif