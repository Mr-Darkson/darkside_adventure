float GetEnderStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

vec3 GetEnderStars(vec3 viewPos, float VdotU) {
    vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos * 1000.0, 1.0)).xyz);

    vec3 starCoord = 0.65 * wpos / (abs(wpos.y) + length(wpos.xz));
    vec2 starCoord2 = starCoord.xz * 0.5;
    if (VdotU < 0.0) starCoord2 += 100.0;
    float starFactor = 1024.0;
    starCoord2 = floor(starCoord2 * starFactor) / starFactor;

    float star = 1.0;
    star *= GetEnderStarNoise(starCoord2.xy);
    star *= GetEnderStarNoise(starCoord2.xy+0.1);
    star *= GetEnderStarNoise(starCoord2.xy+0.23);
    star = max(star - 0.7, 0.0);
    star *= star;

    vec3 enderStars = star * endSkyColor * 3000.0;

    float absVdotU = abs(VdotU);
    float VdotUM2 = pow2(1.0 - absVdotU);
    enderStars *= min(VdotUM2 + 0.015, 0.05) + 0.015;

    float VdotUM3 = smoothstep(0.0, 0.25, absVdotU);
    float endBeamHeight = END_BEAM_HEIGHT * 200.0;
    float beamFactor = END_BEAM_INTENSITY * max0(endBeamHeight - abs(END_BEAM_CENTER_ALT - cameraPosition.y)) / endBeamHeight;
    enderStars *= pow(VdotUM3, min1(beamFactor + 0.001) * min1(END_BEAM_HEIGHT));

    return enderStars * END_STAR_INTENSITY;
}

#if END_BLACK_HOLE == 1
vec3 RenderBlackHoleAt(vec3 color, vec3 wpos, vec3 holeDir, float coreDot, float ringCenterDot, float ringWidth, float haloDot, float intensity, vec3 innerColor, vec3 outerColor) {
    float angDot = dot(wpos, holeDir);
    if (angDot < haloDot) return color;

    // Darken toward black behind the event horizon - safe multiply, never goes negative
    float coreMask = smoothstep(coreDot - 0.00015, coreDot, angDot);
    color *= (1.0 - coreMask);

    // Bright swirling accretion disk ring around the core
    float ringShape = exp(-pow((angDot - ringCenterDot) / ringWidth, 2.0)) * (1.0 - coreMask);

    float swirlAngle = atan(wpos.z - holeDir.z, wpos.x - holeDir.x);
    float swirl = GetEnderStarNoise(vec2(swirlAngle * 2.5, angDot * 900.0));
    swirl = 0.55 + 0.45 * swirl;

    float diskGradient = clamp((angDot - haloDot) / (coreDot - haloDot), 0.0, 1.0);
    vec3 diskColor = mix(outerColor, innerColor, diskGradient);

    color += ringShape * swirl * diskColor * 5.0 * intensity;

    // Soft outer halo/glow
    float halo = clamp((angDot - haloDot) / (ringCenterDot - haloDot), 0.0, 1.0);
    halo = pow(halo, 2.0) * (1.0 - ringShape) * 0.4;
    color += halo * mix(outerColor, innerColor, 0.3) * intensity;

    return color;
}

vec3 ApplyEndBlackHole(vec3 color, vec3 viewPos, float VdotU) {
    vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos * 1000.0, 1.0)).xyz);

    // Main large black hole - fixed direction in the sky, doesn't move with camera position
    color = RenderBlackHoleAt(color, wpos, normalize(vec3(0.35, 0.22, -0.82)),
        0.9994, 0.99855, 0.0016, 0.984, END_BLACK_HOLE_INTENSITY,
        vec3(1.7, 1.2, 0.5), vec3(0.5, 0.6, 1.3));

    #if END_EXTRA_BLACK_HOLES == 1
        // Two smaller black holes elsewhere in the sky
        color = RenderBlackHoleAt(color, wpos, normalize(vec3(-0.68, 0.42, 0.32)),
            0.99975, 0.9993, 0.0009, 0.9975, END_BLACK_HOLE_INTENSITY * 0.75,
            vec3(1.4, 1.0, 0.65), vec3(0.55, 0.7, 1.2));
        color = RenderBlackHoleAt(color, wpos, normalize(vec3(0.15, -0.55, 0.82)),
            0.99985, 0.9996, 0.0006, 0.9985, END_BLACK_HOLE_INTENSITY * 0.65,
            vec3(1.5, 0.9, 0.75), vec3(0.6, 0.55, 1.25));
    #endif

    return color;
}
#endif

#if END_PLANETS == 1 || END_MOONS == 1
vec3 RenderPlanetAt(vec3 color, vec3 wpos, vec3 planetDir, float angularRadius, vec3 litColor, vec3 shadowColor) {
    float angDot = dot(wpos, planetDir);
    float cosRadius = cos(angularRadius);
    if (angDot < cosRadius - 0.001) return color;

    vec3 upRef = abs(planetDir.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 tangent = normalize(cross(planetDir, upRef));
    vec3 bitangent = cross(planetDir, tangent);
    vec3 toPoint = wpos - planetDir * angDot;
    float localX = dot(toPoint, tangent);
    float localY = dot(toPoint, bitangent);
    float localR = length(vec2(localX, localY));

    float sinRadius = sin(angularRadius);
    float discMask = 1.0 - smoothstep(sinRadius * 0.9, sinRadius, localR);
    if (discMask <= 0.0) return color;

    // Simple lit/shadow gradient across the disc, plus subtle noise texture for surface detail
    float shade = clamp(localX / max(sinRadius, 0.0001) * 0.5 + 0.5, 0.12, 1.0);
    float texture = 0.85 + 0.15 * GetEnderStarNoise(vec2(localX * 400.0, localY * 400.0));
    vec3 planetColor = mix(shadowColor, litColor, shade) * texture;

    color = mix(color, planetColor, discMask);
    return color;
}
#endif

#if END_PLANETS == 1
vec3 ApplyEndPlanets(vec3 color, vec3 wpos) {
    color = RenderPlanetAt(color, wpos, normalize(vec3(-0.4, -0.15, 0.75)), 0.168,
        vec3(1.4, 0.55, 0.35), vec3(0.25, 0.1, 0.1)); // reddish planet, 6x size
    color = RenderPlanetAt(color, wpos, normalize(vec3(0.72, 0.55, -0.1)), 0.096,
        vec3(0.55, 0.85, 1.2), vec3(0.08, 0.15, 0.25)); // blue planet, 6x size
    color = RenderPlanetAt(color, wpos, normalize(vec3(-0.15, 0.7, -0.5)), 0.072,
        vec3(1.1, 0.9, 0.55), vec3(0.2, 0.16, 0.08)); // golden planet, 6x size
    return color;
}
#endif

#if END_MOONS == 1
vec3 ApplyEndMoons(vec3 color, vec3 wpos) {
    // Two moons close together, one big and one small
    vec3 bigMoonDir = normalize(vec3(0.55, -0.35, -0.6));
    vec3 smallMoonDir = normalize(vec3(0.62, -0.28, -0.56)); // close to the big moon
    color = RenderPlanetAt(color, wpos, bigMoonDir, 0.024, vec3(1.3, 1.28, 1.25), vec3(0.3, 0.3, 0.32));
    color = RenderPlanetAt(color, wpos, smallMoonDir, 0.010, vec3(1.25, 1.22, 1.2), vec3(0.28, 0.28, 0.3));
    return color;
}
#endif

#if END_BIG_SHOOTING_STARS == 1
vec3 ApplyEndBigShootingStars(vec3 color, vec3 wpos) {
    float cycleDuration = 20.0;
    float cycleIndex = floor(syncedTime / cycleDuration);
    float cycleT = fract(syncedTime / cycleDuration);

    float spawnRoll = GetEnderStarNoise(vec2(cycleIndex * 12.9, 3.7));
    if (spawnRoll > 0.6) return color; // ~60% of slots get a big shooting star

    float activeWindow = 0.25;
    if (cycleT > activeWindow) return color;
    float travelT = cycleT / activeWindow;

    float sA1 = GetEnderStarNoise(vec2(cycleIndex * 3.1, 1.0));
    float sA2 = GetEnderStarNoise(vec2(cycleIndex * 3.1, 2.0));
    float sA3 = GetEnderStarNoise(vec2(cycleIndex * 3.1, 3.0));
    float sB1 = GetEnderStarNoise(vec2(cycleIndex * 3.1, 4.0));
    float sB2 = GetEnderStarNoise(vec2(cycleIndex * 3.1, 5.0));
    float sB3 = GetEnderStarNoise(vec2(cycleIndex * 3.1, 6.0));

    vec3 dirA = normalize(vec3(sA1 - 0.5, sA2 * 0.6 + 0.1, sA3 - 0.5));
    vec3 dirB = normalize(vec3(sB1 - 0.5, sB2 * 0.6 + 0.1, sB3 - 0.5));

    vec3 headDir = normalize(mix(dirA, dirB, travelT));
    float coreWidth = 0.007;

    float headDist = length(wpos - headDir);
    float headGlow = pow(max0(1.0 - headDist / coreWidth), 2.0);

    // Bright glowing tail sampled backward along the path - skip the loop
    // entirely for pixels nowhere near the head or path (most of the sky,
    // most of the time), generous bound to avoid clipping real tail pixels
    float tailGlow = 0.0;
    if (headDist < coreWidth * 100.0) {
        for (int i = 1; i <= 8; i++) {
            float tt = travelT - float(i) * 0.025;
            if (tt < 0.0) break;
            vec3 tailDir = normalize(mix(dirA, dirB, tt));
            float td = length(wpos - tailDir);
            tailGlow += max0(1.0 - td / (coreWidth * 0.7)) * (1.0 - float(i) / 8.0);
        }
    }

    float fadeInOut = min1(travelT * 8.0) * min1((1.0 - travelT) * 4.0);
    float brightness = (headGlow * 2.5 + tailGlow) * fadeInOut * END_BIG_SHOOTING_STAR_INTENSITY;

    color += brightness * vec3(1.3, 1.15, 1.4);
    return color;
}
#endif