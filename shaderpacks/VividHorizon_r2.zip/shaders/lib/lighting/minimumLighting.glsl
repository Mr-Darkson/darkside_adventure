vec3 GetMinimumLighting(float lightmapYM) {
    #if !defined END && CAVE_LIGHTING > 0
        vec3 minLighting = vec3(0.005625 + vsBrightness * 0.043);
        #if CAVE_LIGHTING != 100
            #define CAVE_LIGHTING_M CAVE_LIGHTING * 0.01
            minLighting *= CAVE_LIGHTING_M;
        #endif
        minLighting *= vec3(0.45, 0.475, 0.6);
        minLighting *= 1.0 - lightmapYM;
        #if TRUE_DARKNESS == 1
            minLighting *= 1.0 - (TRUE_DARKNESS_STRENGTH * 0.01);
            // Subtle horror-atmosphere flicker - only meaningful (and only
            // visible) when some floor remains below 100% strength, since
            // at 100% minLighting is already exactly zero and flicker on
            // zero has no effect. Cheap: a single sin() call, no extra
            // texture/noise lookups.
            minLighting *= 0.85 + 0.15 * sin(syncedTime * 0.6);
        #endif
    #else
        vec3 minLighting = vec3(0.0);
    #endif

    minLighting += nightVision * vec3(0.5, 0.5, 0.75);

    return minLighting;
}