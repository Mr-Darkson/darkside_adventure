// Shared fullscreen-quad vertex body
varying vec2 texcoord;
void main() {
    gl_Position = (gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex);
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}
