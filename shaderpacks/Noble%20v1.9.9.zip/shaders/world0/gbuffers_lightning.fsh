#version 430 compatibility

#define PROGRAM_LIGHTNING
#define STAGE_FRAGMENT
#define WORLD_OVERWORLD

#include "/programs/gbuffers/forward.glsl"
