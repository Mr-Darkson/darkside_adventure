#version 430 compatibility

#define STAGE_FRAGMENT
#define WORLD_END

#include "/programs/deferred/atmosphere_write.glsl"
